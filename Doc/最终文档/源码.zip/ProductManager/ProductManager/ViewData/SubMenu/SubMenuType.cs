﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ProductManager
{
    public enum SubMenuType : uint
    {
        SYSTEM_MANAGER_SUBMENU = 1,
        PRODUCT_MANAGER_SUBMENU = 2,
        PLAN_MANAGER_SUBMENU = 4,
    }
}
