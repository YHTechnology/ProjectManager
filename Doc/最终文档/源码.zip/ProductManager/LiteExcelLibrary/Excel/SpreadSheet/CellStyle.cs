﻿using  Lite.ExcelLibrary.BinaryFileFormat;
using System.Windows.Media;

namespace Lite.ExcelLibrary.SpreadSheet
{
    public class CellStyle
    {
        public Color BackColor = Colors.White;
        public RichTextFormat RichTextFormat;
    }
}
